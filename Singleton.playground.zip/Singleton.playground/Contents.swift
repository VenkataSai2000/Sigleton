//Singleton
//Has a single instance to acess as a global variable
//Has a private intializer to restrict creation of multiple instances
//Has a static method
//All the instances of the singleton class are equal
//Sigleton is uswed for logging as best example it will be restricting access to only a single resource

//Only disadvantage is while testing, as multiple instances can't be created.


//Sample code

class Singleton {

    static var shared: Singleton = {
        let instance = Singleton()
        
        return instance
    }()

   
     private init() {}    //Restricts multiple instances
    
   
    func someMethod() -> String {
               return "Hii sigleton"
    }
}

class Client {
    
    static func someCode() {
        let instance1 = Singleton.shared
        let instance2 = Singleton.shared
        //let x=Singleton()
                                                        //Throws an error as the constructor is private we can't create multiple
                                                        //instances of same class.
        
        if (instance1 === instance2) {
            print("Both variables contain the same instance.")
        } else {
            print("Both variables contain different instances.")
        }
        print(instance1.someMethod())
    }
    
}


Client.someCode()
